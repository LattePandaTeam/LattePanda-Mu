20240410

Base on LP-BS-S70NC1R200-SR-A, add IBECC Option for test