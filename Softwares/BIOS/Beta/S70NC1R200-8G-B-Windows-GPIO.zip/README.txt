================================================================================
NEW FEATURES & COMPATIBILITY NOTES
================================================================================

1. Windows GPIO & I2C Support Added
--------------------------------------------------------------------------------
This firmware update introduces native support for GPIO and I2C interfaces 
under Windows operating systems. You can now develop and control these interfaces 
using the following development environments:

* Python: 
  Control both I2C and GPIO using the `winsdk` package.
  
* C# / C++: 
  - Control I2C via the `Windows.Devices.I2c` namespace.
  - Control GPIO via the `Windows.Devices.Gpio` namespace.


2. Hardware Compatibility Notice (LattePanda Mu)
--------------------------------------------------------------------------------
This firmware is compatible with both the 8GB and 16GB RAM versions of the LattePanda Mu compute module. 

*IMPORTANT NOTE FOR 16GB USERS:*
If you flash this firmware onto a 16GB LattePanda Mu, the system will only be able to recognize and utilize 8GB of RAM. 
Please consider this limitation before proceeding with the installation.


3. Release Status & Future Plans
--------------------------------------------------------------------------------
* TESTING ONLY: 
  This firmware is primarily intended for evaluation and testing purposes.

* UPCOMING OFFICIAL RELEASE: 
  Once the official version is ready, separate dedicated builds for both the 
  8GB and 16GB RAM versions of the LattePanda Mu will be released simultaneously, 
  fully restoring 16GB RAM support.

================================================================================

