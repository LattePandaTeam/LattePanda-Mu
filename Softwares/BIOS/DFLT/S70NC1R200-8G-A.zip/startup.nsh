@echo -off 
for %a run (0 15 1) 
  if exist fs%a:\S70NC1R200-8G-A then  
     fs%a:  
     cd S70NC1R200-8G-A 
     cls  
     BIOS.nsh 
  endif  
endfor  
